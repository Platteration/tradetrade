const { chromium, devices } = require('/workspace/tradetrade/node_modules/@playwright/test');
const assert = require('node:assert/strict');
const createdAt = '2026-10-13T00:00:00.000Z';
const favorites = '10000000-0000-4000-8000-000000000001';
const trades = '10000000-0000-4000-8000-000000000002';
const data = { version: 1,
  binders: [{ id: favorites, name: 'Favorites', createdAt }, { id: trades, name: 'Trade binder', createdAt }],
  cards: [{ id: '20000000-0000-4000-8000-000000000001', name: 'Aurora dragon', game: 'An independently published game',
    setName: 'First set', cardNumber: '001/120', variant: 'Foil', condition: 'near-mint', quantity: 3,
    binderId: trades, location: 'Page 2, pocket 4', notes: 'Keep this copy.\nA gift from a friend.', createdAt, updatedAt: createdAt }],
};
(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true });
  try {
    for (const name of ['desktop', 'mobile']) {
      const context = await browser.newContext(name === 'mobile' ? { ...devices['Pixel 7'], viewport: { width: 390, height: 844 } } : { viewport: { width: 1440, height: 1000 } });
      await context.addInitScript(data => localStorage.setItem('tradetrade.portfolio.v1', JSON.stringify(data)), data);
      const page = await context.newPage();
      const errors = [];
      page.on('pageerror', error => errors.push(error.message));
      page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
      const response = await page.goto('http://127.0.0.1:3000/portfolio');
      assert.equal(response.status(), 200);
      await page.getByRole('article', { name: 'Aurora dragon', exact: true }).waitFor();
      await page.waitForTimeout(750);
      await page.evaluate(() => scrollTo(0, 0));
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
      await page.screenshot({ path: `/workspace/tradetrade/docs/design-previews/portfolio-${name}.png`, fullPage: true });
      assert.deepEqual(errors, []);
      await context.close();
    }
  } finally { await browser.close(); }
  console.log('Final card collection desktop/mobile previews captured after entry animations settled.');
})().catch(error => { console.error(error); process.exitCode = 1; });
