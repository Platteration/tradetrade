#!/usr/bin/env bash
set -euo pipefail
container_name="tradetrade-onboarding-smoke-${$}"
docker_local=(env -u DOCKER_HOST -u DOCKER_CONTEXT -u DOCKER_TLS -u DOCKER_TLS_VERIFY -u DOCKER_CERT_PATH docker --host=unix:///var/run/docker.sock)
cleanup() {
  smoke_exit=$?
  trap - EXIT
  "${docker_local[@]}" rm --force "$container_name" >/dev/null 2>&1 || true
  exit "$smoke_exit"
}
trap cleanup EXIT
"${docker_local[@]}" run --detach --name "$container_name" --read-only \
  --cap-drop=ALL --security-opt=no-new-privileges \
  --tmpfs /tmp:rw,noexec,nosuid,size=64m \
  --publish 127.0.0.1::3000 "${1:-tradetrade:verified}"
test "$("${docker_local[@]}" inspect --format '{{.Config.User}}' "$container_name")" = 65532:65532
ready=false
for attempt in $(seq 1 30); do
  status=$("${docker_local[@]}" inspect --format '{{.State.Health.Status}}' "$container_name")
  if [ "$status" = healthy ]; then
    ready=true
    break
  fi
  if [ "$status" = unhealthy ]; then
    break
  fi
  sleep 2
done
if [ "$ready" != true ]; then
  "${docker_local[@]}" logs "$container_name"
  exit 1
fi
port=$("${docker_local[@]}" port "$container_name" 3000/tcp | sed 's/.*://')
SMOKE_PORT="$port" python3 - <<'PY'
import json
import os
import urllib.request

base = 'http://127.0.0.1:' + os.environ['SMOKE_PORT']
opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
with opener.open(base + '/api/health', timeout=5) as response:
    assert response.status == 200
    assert json.loads(response.read()) == {'status': 'ok'}
    assert 'no-store' in [directive.strip() for directive in response.headers['Cache-Control'].split(',')]
with opener.open(base + '/', timeout=5) as response:
    assert response.status == 200
    assert 'text/html' in response.headers['Content-Type']
    assert '<main' in response.read().decode()
with opener.open(base + '/icon.svg', timeout=5) as response:
    assert response.status == 200
    assert 'image/svg+xml' in response.headers['Content-Type']
    with open('/workspace/tradetrade/public/icon.svg', 'rb') as expected:
        assert response.read() == expected.read()
print('Health JSON, homepage, and public SVG passed over HTTP.')
PY
"${docker_local[@]}" exec "$container_name" /nodejs/bin/node -e 'const fs=require("node:fs"); for (const path of ["/app/server.js", "/app/public/icon.svg", "/app/.next/static"]) {fs.accessSync(path,fs.constants.R_OK); const stat=fs.statSync(path); if (stat.uid!==0 || (stat.mode & 0o022)!==0) process.exit(1); let writable=false; try {fs.accessSync(path,fs.constants.W_OK); writable=true;} catch(error) {if (!["EACCES","EROFS"].includes(error.code)) throw error;} if (writable) process.exit(1);} if (process.getuid()===0) process.exit(1); console.log("Runtime is non-root; root-owned app files are readable and not writable.");'
started=$(date +%s)
"${docker_local[@]}" stop --timeout 10 "$container_name"
elapsed=$(( $(date +%s) - started ))
test "$elapsed" -lt 10
printf 'Graceful shutdown passed in %ss.\n' "$elapsed"
