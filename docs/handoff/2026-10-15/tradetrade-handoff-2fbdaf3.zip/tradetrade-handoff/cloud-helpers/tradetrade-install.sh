#!/usr/bin/env bash
set -euo pipefail

cd /workspace/tradetrade
export npm_config_cache=/workspace/.cache/npm
export NEXT_TELEMETRY_DISABLED=1

# Keep the toolchain outside the checkout; package tarball integrity and TLS
# verification remain enabled. The base image supplies npm for bootstrapping.
tradetrade_node=/workspace/.toolchains/node22/node_modules/.bin/node
if [ ! -x "$tradetrade_node" ] || [ "$("$tradetrade_node" --version)" != v22.23.3 ]; then
  npm install --prefix /workspace/.toolchains/node22 --no-save --no-package-lock node@22.23.3
fi
export PATH="/workspace/.toolchains/node22/node_modules/.bin:$PATH"
node --version
npm ci --no-audit --no-fund

# The cloud base image already includes Chromium. Do not download a second
# browser through a blocked host or disable certificate verification.
/usr/bin/chromium --version
