#!/usr/bin/env bash
set -euo pipefail

# Deployment tooling stays outside the application checkout. VERCEL_TOKEN is
# supplied by the environment's secure binding; never pass it on the command line.
export PATH="/workspace/.toolchains/node22/node_modules/.bin:/workspace/.toolchains/vercel/node_modules/.bin:$PATH"
export XDG_CACHE_HOME=/workspace/.cache
export XDG_DATA_HOME=/workspace/.cache/cli-data
export VERCEL_TELEMETRY_DISABLED=1
export DO_NOT_TRACK=1
export NO_UPDATE_NOTIFIER=1

exec vercel "$@" --global-config /workspace/.cache/vercel-config
