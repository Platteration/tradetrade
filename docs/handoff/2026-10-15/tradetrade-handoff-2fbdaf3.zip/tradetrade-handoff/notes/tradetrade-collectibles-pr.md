## What changed.

The app previously tracked trading cards and graded-card targets. Add `/inventory` for CS:GO / CS2 skins, books and custom collectible categories, with manual quantities, locations, costs, value estimates and buying/selling targets. Both prelaunch designs now introduce the broader portfolio and link to it; trading cards retain their binder workflow.

## Behaviour changes.

- Skin entries store weapon, finish, exterior, exact float text, pattern, StatTrak and Souvenir details. Books store author, edition, format and ISBN / identifier text. Other entries require a custom category. All entries support name, quantity, condition, location and notes; search, category filters, recent/name sorting, editing and confirmed deletion are available.
- Prices are optional, per item and entered manually in USD/EUR/GBP/CAD/AUD/JPY. Empty amounts mean unknown; explicitly entered zero costs/estimates remain valid. Buy/sell targets must be positive and compare inclusively with the last unit estimate. Its recording date uses the actual browser time, including when a restored record has a future update date.
- Portfolio summaries include quantity and stay separate by currency. Partial cost/value totals are labeled subtotals with priced-entry coverage; absent prices show Not recorded. Estimated change compares only entries with both cost and estimate. BigInt arithmetic preserves totals beyond the safe integer range. These are recorded estimates, with no Steam inventory connection, live market polling, currency conversion, trade execution or background delivery.
- Changing an item's identity, condition or subtype clears its stale estimate with a visible warning. Unrelated quantity/location/notes/target edits keep the estimate's recorded date. Changing currency clears all cost/value/target draft fields for explicit re-entry; changing category resets subtype details and the estimate while preserving other shared fields. Cancel leaves the saved entry intact.
- Inventory uses its own `tradetrade.inventory.v1` store and JSON backup, scoped to this origin/browser, without requiring an account. Limits are 5,000 entries and 2 MiB serialized data, subject to browser quota. Partial imports keep existing IDs and report skipped records. Corrupt bytes remain downloadable until explicit recovery; failed save attempts retain stable IDs and exportable drafts. Web Locks/revision checks, visible one-tab fallback, operation guards and native navigation warnings protect edits and imports.
- Card and graded-alert storage formats are unchanged. Their pages now link to the broader portfolio. Existing card entry links remain on both designs. The production container smoke check now includes `/inventory`; no dependencies or CSP allowances were added.
- Desktop/mobile visual previews include the updated landing pages and a fictional three-category portfolio. Example prices are manually entered test data.

## Verified.

- Before edits, the published foundation passed `npm run check` (43 unit tests, 14 conventions passed / one inapplicable skip) and `npm run test:e2e` (108 checks). Current default `b9a801f` differed only by removal of an unused lint comment and also passed `npm run check`. Existing assertions were retained.
- Final `npm run check`: exit 0; lint and types pass, all 60 unit tests pass, conventions remain 14 passed / one inapplicable skip. Production build succeeds on Node 22.23.3.
- Initial complete `npm run test:e2e`: exit 0; all 150 desktop/mobile cases pass. After the final skin-tag search improvement and added real mobile-tap, focus and ordering assertions, `npx playwright test e2e/inventory.spec.ts e2e/portfolio-layout.spec.ts`: exit 0; all 46 cases pass against the rebuilt production app. No assertions were weakened or skipped.
- New unit/browser cases cover typed category details, exact 18-digit float bounds, unknown/zero prices, quantity and mixed-currency totals, paired coverage, inclusive targets, stale-estimate clearing, actual recording times, backup recovery, immutable ID collisions, repeat imports, quota failure, stable drafts, competing tabs, delayed locks/file reads, storage denial, missing secure IDs, native Back/navigation guards and literal rendering under fresh CSP nonces. Card/alert stores remain byte-identical after inventory writes/imports.
- Isolated guard mutations fail assertions for rounded float validation, omitted quantity multiplication in change totals and bypassed stale-write protection. A separate reviewer independently ran all 17 new domain/storage tests successfully and reviewed UI/storage/error paths.
- Desktop/mobile Chromium visual review covers empty/populated, selected/hovered/focused controls, category editors, validation and disabled controls at 1440, 390 and 320 CSS pixels. Browser measurements pass WCAG AA for text, control boundaries and focus outlines. Add item remains above the fold at 320px, and there is no horizontal overflow. Real emulated touch taps return focus to their opener; canonical screenshots scroll to the top to avoid a full-page capture artifact involving the hidden fixed skip link.
- `npm audit --omit=dev --audit-level=high`: exit 0, zero findings. A manually started final production process returns exact `{"status":"ok"}` from `/api/health`; canonical previews are captured from that build.
- Published commit `d9acf93952be1b259173b4deae0949915bc2f163`: [push CI](https://github.com/Platteration/tradetrade/actions/runs/38338607809) and [PR CI](https://github.com/Platteration/tradetrade/actions/runs/38338649909) both succeed. Read final job/step results: frozen install, lint/types, all 60 unit checks, conventions, build and the complete 150-case suite with matching Chromium pass. Production dependency audit, container build, high/critical image scan and restricted-container smoke including `/inventory` also pass.

## Not verified.

- Vercel deployment, public HTTPS/domain and hosted behaviour remain pending hosting access. Local production verification is not a live deployment.
- Physical phones, Safari/Firefox, physical speaker/headphone sound quality and the new release on Node 24. Checks use Chromium in desktop/mobile emulation; GitHub CI installs Playwright's matching version.
- Live prices, Steam synchronization, catalogs, currency conversion, optional accounts/sync and trading are not implemented.
- Cloud snapshot publication/fresh-task restoration and GitHub administrative protection settings. Updating an environment draft does not publish it.

## Follow-ups.

- Connect Vercel access, deploy the tested commit and run `test:deployed` against the final HTTPS origin.
- Connect an agreed pricing provider before claiming automatic price monitoring; keep exact collectible identity and source timestamps.
- Add optional accounts/sync while preserving device-first storage and portable backups.
- Choose the final name/domain and review prelaunch indexing settings.
- Track the existing unpatched development-only `braces` advisory [GHSA-vfj7-8cjw-p6xm](https://github.com/advisories/GHSA-vfj7-8cjw-p6xm) through Next's ESLint plugin. No vulnerable rootDir glob is configured and website input cannot reach that tooling path; no audit exclusions or forced downgrades were added.
- Review/save/publish the updated environment configuration when retaining this setup for future sessions.
