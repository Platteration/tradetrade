# Vercel publishing handoff

Both designs are already committed and pushed in `Platteration/tradetrade`,
commit `2fbdaf39ca17d010d6d4aedf8a4482a439790e2d` (PR #7).
The user selected Vercel and authorized publishing them. No Vercel deployment
has been created: the account credential is not connected.

## Prepared inputs

- Vercel CLI 63.1.2 is installed outside the checkout at
  `/workspace/.toolchains/vercel/node_modules/.bin/vercel`.
- Run it with `bash /workspace/setup/tradetrade-vercel.sh ...`. The wrapper uses
  writable task-local config/cache paths, disables telemetry/update checks,
  and preserves the session proxy and TLS trust.
- `/workspace/setup/vercel-source-2fbdaf3` contains a clean `git archive` of the
  exact published commit (110 tracked files). It includes both designs, the collectible
  inventory, card collection, graded alerts, website sources and account preparation, and
  excludes local build outputs, dependencies, credentials and Git metadata.
  Deploy this copy so CLI linking metadata does not alter the source checkout.
- The app needs no runtime secrets or application environment variables. Leave
  `BUILD_STANDALONE` unset for the normal Vercel Next.js build.

## Required connection

No Vercel credential is currently configured. Add deployment access securely through
environment settings, for the intended Vercel account and team. Never ask for or print
token values; a `VERCEL_TOKEN` secret, if used, belongs only at `api.vercel.com`.
The current configuration allows `api.github.com`, `api.vercel.com` and `*.vercel.app`.
Saving the draft did not establish runtime access or publish the cloud snapshot.

After the connection is applied, recheck environment readiness, then use normal
CLI identity/team/project reads. `VERCEL_TOKEN` is consumed from the environment;
never pass the value through `--token` or enable debug logging. Select the token's
intended team. If several teams are accessible and no target is inferable, obtain
the user's team choice. Inspect any existing `tradetrade` project before changing
it; do not overwrite an unrelated deployment.

For the selected project and team, the verified CLI options are:

```sh
bash /workspace/setup/tradetrade-vercel.sh link --yes \
  --project tradetrade --scope TEAM_SLUG \
  --cwd /workspace/setup/vercel-source-2fbdaf3
bash /workspace/setup/tradetrade-vercel.sh deploy --yes \
  --scope TEAM_SLUG --cwd /workspace/setup/vercel-source-2fbdaf3
```

These commands prepare a preview. Verify its actual HTTPS origin before promoting that
verified deployment in the intended Vercel project. Publication is already authorized.
These authenticated operations have not run. Do not paste `TEAM_SLUG` literally.
CLI `--dry` also required credentials in this environment; the temporary dry-run
path was unavailable. No anonymous deployment was created.

## Verify the hosted result

Record the actual deployment ID and production URL returned by Vercel, wait for
the build to succeed, and verify anonymous HTTPS access to `/`, `/alternate`,
`/portfolio`, `/alerts`, `/inventory`, `/sources`, `/account` and `/api/health`. Check the expected health JSON, A/B navigation, browser/CSP errors,
security headers, fresh script-matching nonces, private/no-store HTML, and both
desktop/mobile layouts. Keep prelaunch noindex/robots intact. Do not relax CSP to
make Vercel's optional toolbar work.

The repository's shared convention keeps `engines.node` at `>=22`; Vercel's
current installed build-utils selects Node 24 for that range. Verify the actual
hosted Node version/build logs. Local Node 24 compatibility checks are separate
from a real Vercel build and must not be reported as a completed deployment.

Current release validation uses Node 22.23.3: all 84 unit tests and 14 conventions
pass (one inapplicable Pages skip), lint/types and the production build succeed.
The local Node 22 browser run passed 184/186 initially; two new assertions incorrectly
looked for a modal warning outside its dialog. The corrected, stronger two-case test
passes with all storage/conflict/export assertions intact. All 186 cases then passed
through the full deployed runner against a local Node 24.21.0 production process.
Complete synthetic Google/Apple settings and an ephemeral generated key still leave
providers disabled, with no session or credential exposure. This is local compatibility
evidence, not a real provider or Vercel integration. Production audit reports zero
findings. Independent restricted-container build, HTTP, hydration and shutdown checks pass.
Both GitHub runs for this exact commit are green: push 38396295771 and PR 38396302964.
Final job/step conclusions confirm frozen install, lint/types/unit/conventions/build,
the complete browser suite, production audit, image build, HIGH/CRITICAL Trivy scan and
restricted-container verification all pass. Raw CI log downloads are network-blocked;
readable API job/step results were verified. Recheck these results before deployment.

Current product scope: `/portfolio` provides on-device card collections, binders, CSS
3D movement and optional synthesized card sound. `/alerts` stores graded-card buy/sell
targets against manually entered prices. No live pricing or background notifications
are connected. Optional Google/Apple accounts are prepared but not activated; do not
set provider secrets or expect sign-in to work merely because credentials are present.
Read docs/authentication.md before implementing the real adapter/session service.
`/inventory` adds CS skins, books and custom collectibles, with quantities, locations,
manual cost/value estimates and buy/sell targets. It has its own separate backup, so
export its backup separately. No Steam inventory is connected.
`/sources` keeps safe public HTTPS links and manual price observations; it performs no
automatic fetching, monitoring or remote submissions. Sources have a fourth backup.
Preview, production and custom-domain origins have separate browser data; export/import
all four workspace backups before changing origins.

GitHub private vulnerability reporting is disabled and enabling it returned administration
HTTP 403. Review repository protections with owner access. The known development-only
braces advisory remains tracked; production dependencies are clear.

After deploying the exact tested commit, run
`DEPLOYMENT_URL=https://the-actual-origin npm run test:deployed` against the preview,
then the final production origin. See `docs/operations.md` for recovery and rollback.
