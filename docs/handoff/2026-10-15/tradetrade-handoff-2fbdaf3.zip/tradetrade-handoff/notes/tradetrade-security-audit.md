# Prelaunch foundation audit and visual comparison

Published commit: ebe163c7b43769b697f9e86ac2c5fbd0de237617

Pull request: https://github.com/Platteration/tradetrade/pull/2

## What changed.

Turn the documentation-only placeholder into a tested Next.js 16 / React 19 / Node 22 prelaunch foundation. It serves two responsive coming-soon designs, a custom 404 and process health endpoint; the temporary name is centralized in `src/lib/site.ts`. No trading domain, accounts, listings or payments are invented.

Add strict TypeScript, nonce-based browser security, regression tests, the exact repository-family conventions test, SHA-pinned CI, dependency updates and a digest-pinned distroless production container. Update setup/deployment documentation and clarify the security reporting policy when GitHub private reporting is unavailable.

Compare the implemented [desktop and mobile previews](https://github.com/Platteration/tradetrade/blob/codex/launch-foundation/docs/design-previews/README.md). The original is cream/forest green; **After hours** uses charcoal/citron, oversized typography and geometric SVG artwork.

| A — Original | B — After hours |
| --- | --- |
| ![Original desktop](https://raw.githubusercontent.com/Platteration/tradetrade/ebe163c7b43769b697f9e86ac2c5fbd0de237617/docs/design-previews/original-desktop.png) | ![After hours desktop](https://raw.githubusercontent.com/Platteration/tradetrade/ebe163c7b43769b697f9e86ac2c5fbd0de237617/docs/design-previews/alternate-desktop.png) |

## Behaviour changes.

- The original homepage remains at `/`; `/alternate` adds the After hours design with matching icon/title. Both expose labelled A/B links with a current-page indicator, keyboard focus and 44px targets. Navigation uses normal URLs/browser history; it stores no preference. The alternate has a dark-appropriate skip-link focus treatment.
- Public homepage and `GET /api/health` returning `{"status":"ok"}`; health means process liveness only. Unsupported health mutations return 405 and missing pages return 404.
- Fresh server-generated CSP nonces on dynamic HTML; client nonce/CSP headers are replaced, and HTML is private/no-store. Production blocks nonce-free HTML-injected scripts, event handlers, framing, plugins and base-URL injection; development has explicit Next tooling exceptions.
- HSTS for production HTTPS, MIME/referrer/permissions/opener protections; indexing disabled until a deliberate launch review. Robots/noindex do not provide access control.
- Standard Next build/start locally; standalone output in Docker. Production runs as UID 65532 with root-owned files, without a shell/npm/package manager, and supports a read-only root filesystem, healthcheck and graceful termination.
- CI checks lint/types/unit/conventions/build/browser behavior, audits production npm dependencies, scans the shipped image for high/critical OS/library findings, and smoke-tests the restricted container. Weekly execution begins once this workflow is on the default branch.
- Disable Next's automatic AGENTS.md generation so development startup preserves existing repository instructions.

## Verified.

Baseline: nine documentation/configuration files, no executable application/tests. Existing user files were clean before implementation.

- `npm run check`: exit 0; lint/typecheck pass, 4 security tests pass, 14 conventions checks pass, one inapplicable Pages test skipped. Conventions rerun after final workflow edits: same result.
- `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH=/usr/bin/chromium npm run test:e2e`: exit 0; production build and all 32 desktop/mobile browser tests pass. The 18 original tests were also run unchanged against the new design before the additional suite. Checked real CSP enforcement, fresh matching nonces, spoof rejection, health/405, 404, prefetch, robots, measured text contrast and keyboard focus. Additional checks cover A/B navigation/history, direct alternate access and metadata, alternate nonce protections, both palettes at 320px, and text/focus contrast across selection/hover/keyboard states.
- The injection test first proves the payload executes in an isolated CSP-free control, then verifies it is blocked with the actual production headers. Earlier DevTools-created script insertion tested a trusted strict-dynamic descendant instead of parser HTML injection; the model was corrected without weakening nonexecution assertions or CSP.
- Three isolated negative security mutations made tests fail (event-handler allowance, trusting a client nonce, cached nonces).
- Visually inspected both designs in desktop/mobile Chromium at rest and in hover/focus states; committed four clean production screenshots in `docs/design-previews/`. Corrected the dark-page skip-link focus contrast after visual review and verified the regression test fails before the fix (2.57:1) and passes afterward.
- Repeated frozen installation using the saved cloud installer: exit 0, lockfile unchanged. Development startup/restart and representative HTTP requests pass; AGENTS.md remains unchanged.
- Foundation local Docker build and restricted-container smoke: exit 0; expected health JSON, homepage, exact SVG, non-root execution, read access/write denial and immediate graceful shutdown verified.
- Trivy 0.75.0 (official artifact checksum verified), final distroless image OS/library scan at HIGH/CRITICAL: exit 0, zero findings. The original general-purpose runtime had findings and was replaced; no scanner exclusions or verification bypasses were added.
- `npm audit --omit=dev --audit-level=high`: exit 0, zero reported vulnerabilities. Full `npm audit --json`: exit 1 for the development-only advisory below.
- Foundation GitHub CI passed on published commit `c0ab4650c9ffbaf09a57747024c3d0e2dd47f50a`: [push run](https://github.com/Platteration/tradetrade/actions/runs/38087846582) and [PR run](https://github.com/Platteration/tradetrade/actions/runs/38087902299). All three jobs (`check`, `audit`, `docker`) succeeded. Read the PR run's step results: matching Playwright Chromium installation, browser suite, shipped-image vulnerability scan and restricted-container smoke all succeeded.

- Final design commit `ebe163c7b43769b697f9e86ac2c5fbd0de237617`: [push CI](https://github.com/Platteration/tradetrade/actions/runs/38088833641) and [PR CI](https://github.com/Platteration/tradetrade/actions/runs/38088834517) both succeeded. Read the final PR job/step results: lint, types, tests, build, matching Chromium installation/browser suite, production dependency audit, container build, high/critical image scan and restricted-container smoke all passed.

## Not verified.

- Full hosted CI log download was blocked by the cloud network policy for GitHub's results host; job and step conclusions were verified through the GitHub API.
- Production hosting, DNS/TLS and public deployment; no hosting target is configured. Accounts, authorization, exchanges, payments and recovery do not exist yet.
- Safari/Firefox and physical mobile devices. Local tests used Debian Chromium 154 because the cloud proxy blocked Playwright's matching browser download; hosted CI successfully installed and tested with its matching Chromium.
- Branch-protection settings: GitHub's integration returned 403. Secret-scanning/push-protection status was not exposed by repository metadata.
- Cloud snapshot publication/restoration in a new task. Setup/start instructions are saved in the environment draft; saving a draft does not publish it.

## Follow-ups.

- **One unpatched high-severity development-tool advisory:** [GHSA-vfj7-8cjw-p6xm](https://github.com/advisories/GHSA-vfj7-8cjw-p6xm), `braces <=3.0.3`, propagated as five npm findings through Next's ESLint plugin. Confirmed stack exhaustion with an attacker-controlled `settings.next.rootDir` pattern. This config uses no such glob, and website input cannot reach it. No upstream patch exists; do not force-downgrade Next/remove checks to conceal it.
- ESLint 9 is deprecated upstream but required by the repository family's pinned conventions; coordinate a family-wide upgrade.
- Private vulnerability reporting is **disabled**. Enabling it through the integration was denied (403); the owner must enable it in GitHub settings before relying on the documented private channel.
- Define the first product journey, choose the final name/domain/host, and audit those features before calling the product launch-ready.
- Review/save/publish the cloud environment configuration through the product to retain the prepared snapshot.

