# Trade design files

These files accompany source commit `2fbdaf39ca17d010d6d4aedf8a4482a439790e2d`.

- `previews/README.md` is the gallery of 14 current production screenshots:
  original, alternate, collection, alerts, inventory, website sources and account
  preparation, each at desktop and mobile sizes.
- `icons/` contains both editable SVG app icons.
- `editable/src/` contains the actual application source, CSS, components, card
  motion/audio code and site-name configuration. It is not a standalone project;
  use `tradetrade-source-2fbdaf3.zip` for the lockfile, build configuration and tests.
- `review-images/` preserves four additional visual review states from this
  conversation. They are historical focus/validation captures, not replacements
  for the current gallery. Their original names and actual dimensions are listed
  in `review-images/manifest.json`.

The screenshots use fictional entries and manually entered example prices.
Motion and synthesized sound are implemented in code; there is no separate audio
recording or 3D model asset. No Figma or Sketch file was created in this workspace.

Use Node 22 and the main source README to run the project. The original design is
at `/`, the alternate at `/alternate`; all workspaces are shared by both looks.

Repository: https://github.com/Platteration/tradetrade
