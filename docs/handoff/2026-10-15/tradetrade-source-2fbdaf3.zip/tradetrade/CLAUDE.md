@AGENTS.md

# tradetrade

A Next.js collectible portfolio. The working name is kept in
`src/lib/site.ts`. `/portfolio` supports manual card entries and named binders; a free-text
location can identify a physical page and pocket. Entries live in browser storage and
can be exported/imported as JSON backups. Accounts and synchronization are not connected.
`/inventory` adds CS:GO / CS2 skins, books and custom collectible categories. Its own
version 1 store and backups keep typed item details, quantities, locations, manual
per-unit cost/value estimates and optional buy/sell targets. Totals stay separate by
currency, use exact BigInt arithmetic, and expose priced coverage. Estimated change
compares only entries with both cost and value; unpriced items must never imply zero.
Steam inventory, book catalogs, live prices and currency conversion are not connected.
`/alerts` stores graded-card buy/sell targets and manually recorded prices in its own
version 1 store, with separate backups. A target status refers to the last recorded price;
there is no market polling or closed-browser notification service. Card motion uses CSS
and respects reduced motion; optional Web Audio rustling starts off.
Do not imply a card catalog, live prices, payment processing or trade execution exists.

`/sources` saves user-provided public HTTPS product links and manual price observations
in its own `tradetrade.sources.v1` store. Saving a source never fetches a website or submits
a request to the maintainer. Observations are separate from inventory estimates and
graded-card alerts. Keep executable URLs, credentials and private-address links rejected;
client URL validation is not a substitute for future server-side SSRF defenses. See
`docs/website-tracking.md` before adding any ingestion service.
`/account` prepares optional Google/Apple configuration and displays unavailable sign-in
controls. Credentials alone must never enable authentication; there is no OAuth adapter,
session or synchronization service yet. Read `docs/authentication.md` before connecting one.
Keep provider secrets server-only, and keep on-device collections usable without an account.

Use Node 22 and `npm ci`. Run `npm run check`, `npm run test:e2e`, and
`npm audit --omit=dev --audit-level=high` before proposing a release. The browser suite
builds and starts its own production server. CI also validates the Docker image.
After deploying, run `DEPLOYMENT_URL=https://the-actual-origin npm run test:deployed`.
This requires an explicit origin and runs the same browser checks without building or
starting a local server. See `docs/operations.md` for deployment and recovery steps.

Portfolio persistence is scoped to this browser and origin. Treat save failures,
cross-tab conflicts and backup recovery as data-loss risks: make failures visible,
preserve unsaved changes for export, and never silently replace saved data. Import must
keep existing records and report skipped invalid items. Changing a hostname does not
move a collection; export/import is required. Keep storage-version compatibility in mind
when changing the model or rolling back a deployment.

`src/proxy.ts` generates a fresh CSP nonce per request. Keep the root layout dynamically
rendered and use CSS files instead of inline styles. Never relax the production policy
to fix a page. Development has explicit allowances for Next's tooling only.

`/api/health` checks process liveness, not database or external-service readiness.
No database, authentication, payment provider, application credentials or analytics are
configured. Robots and metadata intentionally discourage indexing until launch review.
They are not access controls; the application routes are public. Portfolio records remain
on the user's browser rather than being published with the application.

The shared conventions document includes historical references to this repository's
placeholder stage. This repository now carries the first-code tooling those references
deferred; leave the shared document and test byte-identical to the other repositories.

## Conventions

This repository follows `CONVENTIONS.md`, which is identical in every platteration
repository and pinned by the conventions test (`npm run test:conventions`, or
`tests/test_conventions.py` in a Python repository): the script set (`test`,
`typecheck`, `lint`, `check`, `test:e2e`, `test:all`), Node 22 via `.nvmrc`, one
`.editorconfig`, ESLint per stack, the `ci.yml` shape, the documents every repository
carries and the README skeleton. The repository's check command (`npm run check`, or
`ruff check .` then `pytest -q` in a Python repository) is the gate before a push. To
change a convention, change it in every repository in one pass and update the hashes in
the test.
